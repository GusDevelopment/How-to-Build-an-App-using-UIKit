//
//  ContentView.swift
//  HelloWorld
//
//  Created by Gustavo Espinoza on 2/4/20.
//  Copyright © 2020 Gustavo Espinoza. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
