//
//  ViewController.swift
//  Lesson02Project
//
//  Created by Gustavo Espinoza on 2/10/20.
//  Copyright © 2020 Gustavo Espinoza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

