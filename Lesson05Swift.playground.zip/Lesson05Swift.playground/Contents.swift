import UIKit

// This is a comment
// Variables
var str = "Hello, playground"
print(str)
str = "some data"
print(str)

// Constants
let con = "more data"

// Data Types
// String = a string of characters
// Boolean = True or False
// Integer = whole number from negative to postive including 0
// Float = decimal numbers

//var b = false
//print(b)

//var i = 32
//i = 0
//i = -10

//var f = 0.3493

//Exercise

//Addition
var a = 20 + 5

//Subtraction
var b = 20 - 5

//Multiplication
var c = 20 * 5

//Division
var d = 20 / 5

//Modulus
var e = 20 % 2

//Equations with variables
var f = (a * b) + (c / d)

//Increment the variable
f = f + 1

// 0r ...
f += 1

//Decremnt the variable
f -= 1

//Multiply the variable
f *= 2

//Divide the variable
f /= 4

//Additional Operators


// Absolute number
var g = abs(-1)

//Ceiling
var h = ceil(1.8)

//Floor
var i = floor(1.4)

//Sqaure Root
var j = sqrt(36)

// Power
var k = pow(2, 4)


