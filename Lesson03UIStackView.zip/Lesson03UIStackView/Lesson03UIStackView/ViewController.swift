//
//  ViewController.swift
//  Lesson03UIStackView
//
//  Created by Gustavo Espinoza on 2/11/20.
//  Copyright © 2020 Gustavo Espinoza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

