import UIKit

// Classes are used to group methods that do similar things
class spaceship {
    // variables inside of a class are called properties
    var fuelLevel = 100
    var name = ""
    
    // Functions inside a class are called methods
    func cruise() {
    //code to initiate cruising
        print("Cruising is initiated for \(name)")
    }

    func thrust() {
    //code to initiate cruising
        print("Rocket thrusters initiared for \(name)")
    }
}


var myShip = spaceship()
myShip.name = "Tom"
myShip.cruise()
myShip.thrust()

//Exercise

class spaceship2 {
    var fuelLevel = 50
    
    func liftOff() {
        fuelLevel -= 50
        print("We have lift off!")
        print("The current fuel level is \(fuelLevel)")
    }
    
    func addFuel(fuel:Int) {
        fuelLevel = fuelLevel + fuel
        print("Fuel added.")
        print("Current fuel level is \(fuelLevel)")
    }
    
    func thrust() {
        fuelLevel -= 15
        print("Rocket is thrusting")
        print("Current fuel level is \(fuelLevel)")
    }
    
    func cruise() {
        fuelLevel -= 15
        print("Rocket is thrusting")
        print("Current fuel level is \(fuelLevel)")
    }
}

var myShip2 = spaceship2()
myShip2.addFuel(fuel: 50)
myShip2.liftOff()
myShip2.thrust()
myShip2.cruise()


