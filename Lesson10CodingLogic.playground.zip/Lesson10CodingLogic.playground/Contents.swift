import UIKit

func vowelDetector(vowel:String) -> Bool {
    
    if vowel.contains("a") || vowel.contains("e") || vowel.contains("i") || vowel.contains("o") || vowel.contains("u") {
        return true
    } else {
        return false
    }
 
}


vowelDetector(vowel: "Real Madrid")
vowelDetector(vowel: "sync")
