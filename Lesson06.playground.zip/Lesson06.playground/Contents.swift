import UIKit

var str = "Hello, playground"

// Basic Function
func sayHello() {
    print("hello!")
}

sayHello()

// Function with parameters
func sayHelloTo(name:String, age:Int) {
    print("Hello \(name), you're \(age)")
}

sayHelloTo(name: "Gus",age: 26)

// Function with return value

func addFourTo(x:Int) -> Int {
    let sum = x + 4
    return sum
}

var result = addFourTo(x: 6)
print(result)


// Exercise
// 1
func goodMorning() {
    print("Good Morning")
}

goodMorning()


//2

func printTotalWithTax(subtotal:Double) {
    let total = subtotal * 1.13
    print(total)
}

printTotalWithTax(subtotal: 14)

//3

func getTotalWithTax(subtotal:Double) -> Double{
    let total = subtotal * 1.13
    return total
}

var total = getTotalWithTax(subtotal: 14)
print(total)


//4

func calculateTotalWithTax(subtotal:Double, tax:Double) -> Double{
    let total = subtotal * tax
    return total
}

var total2 = calculateTotalWithTax(subtotal: 14, tax: 1.13)
print(total2)

